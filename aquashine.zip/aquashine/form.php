<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once 'submit.php' ; ?>
<!-- Status message -->
<?php if(!empty($statusMsg)){ ?>
    <div class="status-msg <?php echo $status; ?>"><?php echo $statusMsg; ?></div>
	<div class="hid">
<?php } ?>

<div class="col-xl-6">
                <div class="contact-form-box1">
                    <div class="top-title">
                        <h2>Enquire With Our Team</h2>
                    </div>
                    <form id="contact-form" name="contact_form" class="default-form1" action="#" method="post">
                        <div class="input-box"> 
                            <input type="text" name="form_name" value="" placeholder="Your Name" required="">
                            <div class="icon">
                                <i class="fa fa-user" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="input-box"> 
                            <input type="email" name="form_email" value="" placeholder="Email Address" required="">
                            <div class="icon">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                        </div> 
                        <div class="input-box">
                            <div class="select-box">
                                <div class="round-shape"></div>
                                <select class="wide">
                                   <option data-display="Service You Need">Service You Need</option>
                                   <option value="1">Bottled Water</option>
                                   <option value="2">Water Dispenser</option>
                                   <option value="3">Water Trailers</option>
                                </select>
                            </div>
                            <div class="icon">
                                <i class="fa fa-cog" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="input-box">
                            <input type="text" name="form_address" value="" placeholder="Your Address">
                            <div class="icon">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                            </div>
                        </div>  
                        <div class="button-box">
                            <div class="left">
                                <div class="checked-box1">
                                    <input type="checkbox" name="skipper1" id="skipper" checked>
                                    <label for="skipper"><span></span>I agree to receive updates<br> from Aguapure</label>
                                </div>
                            </div>
                            <div class="right">
                                <button class="btn-one" type="submit" data-loading-text="Please wait...">
                                    <span class="round"></span>
                                    <span class="txt">submit</span>
                                </button> 
                            </div>
                        </div>  
                    </form>

                </div>
            </div>