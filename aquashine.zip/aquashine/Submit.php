<?php 
// Email configuration 
$toEmail = 'premkumarragav@gmail.com'; 
$formEmail = 'test@prem.com'; 
 
$postData = $statusMsg = $nameErr = $emailErr = $numErr = ''; 
$status = 'error'; 
 
// If the form is submitted 
if(isset($_POST['submit'])){ 
    // Get the submitted form data 
    $postData = $_POST; 
    $name = trim($_POST['contact-name']); 
    $email = trim($_POST['contact-email']); 
	$number = trim($_POST['contact-phone']); 
	$subject= trim($_POST['contact-subject']); 
    $message = trim($_POST['contact-message']); 
    
    // Validate form fields 
    if(empty($name)){ 
         $nameErr .= 'Please enter your name.<br/>'; 
    } 
    if(empty($email) || filter_var($email, FILTER_VALIDATE_EMAIL) === false){ 
        $emailErr .= 'Please enter a valid email.<br/>'; 
    } 
	// require a number from user
	if(trim($_POST['contact-phone']) === '') {
		 $numErr .= 'Please enter a valid number.<br/>'; 
	} else {
		$number = trim($_POST['contact-phone']);
	}
    
     
	 
    if(empty($nameErr)&&empty($emailErr)&&empty($numErr)){ 
        // Send email notification to the site admin 
        //$subject = 'New contact request submitted'; 
		$body = "You have got a new message from the contact form on your website -  Sumaithangi Trust  :
          
            <p><b>Name: </b>".$name."</p> 
            <p><b>Email: </b>".$email."</p> 
			<p><b>Number: </b>".$number."</p> 
			<p><b>Subject: </b>".$subject."</p> 
            <p><b>Message: </b>".$message."</p> 
        "; 
         
        // Always set content-type when sending HTML email 
        $headers = "MIME-Version: 1.0" . "\r\n"; 
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
        // Header for sender info 
        $headers .= 'From:'.$name.' <'.$formEmail.'>' . "\r\n"; 
         
        // Send email 
        @mail($toEmail,'Message from Sumaithangi Contact Page', $body, $headers); 
        @mail('ragan2014@gmail.com','Message from Sumaithangi Contact Page', $body, $headers); 
         
        //$status = 'success'; 
        //$statusMsg = ' Thank you! We will get back to you soon.'; 
       // $postData = ''; 
	   //header("Location:https://athulyahomecare.com/lp/home-care-services-in-chennai/thank-you.html");
	   echo("<script>location.href = 'thankyou.php';</script>");
    }
}
?>