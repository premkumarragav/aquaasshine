<!--Start footer area -->  
<footer class="footer-area">
    <!--Start Footer-->
    <div class="footer">
        <div class="container">
            <div class="row text-right-rtl">

                <!--Start single footer widget-->
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 wow animated fadeInUp" data-wow-delay="0.1s">
                    <div class="single-footer-widget marbtm50">
                        <div class="our-company-info">
                            <div class="footer-logo">
                                <a href="index.php" style="background-color: white;"><img src="assets/images/resources/logo5.png" alt=""/></a>
                            </div>
                            <div class="text-box">
                                <p>Trust Aquaasshine for all your RO purifier sales and service needs, providing you with the purest water possible.</p>
                            </div>
                            <div class="our-company-info-list">
                                <ul>
                                    <li><span class="icon-check-mark"></span>Free Delivery</li>
                                    <li><span class="icon-check-mark"></span>Free Installation</li>
                                </ul>
                            </div>
                        </div>     
                    </div>
                </div>
                <!--End single footer widget-->

                <!--Start single footer widget-->
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 wow animated fadeInUp" data-wow-delay="0.3s">
                    <div class="single-footer-widget martop marbtm50">
                        <div class="title">
                            <h3>Useful Links</h3>
                            <div class="decor">
                                <img src="assets/images/shape/decor.png" alt="">
                            </div>
                        </div>
                        <div class="footer-widget-links">
                            <ul class="pull-left">
                                <li><a href="#">Service</a></li>    
                                <li><a href="#">Products</a></li>             
                                <!-- <li><a href="#">Career</a></li>              -->
                                <!-- <li><a href="#">Contact</a></li>             
                                <li><a href="#">Feedback</a></li>                         
                                <li><a href="#">Location</a></li>                          -->
                            </ul>
                            <ul class="pull-left marleft-60">
                                <!-- <li><a href="#">Benefits</a></li>    
                                <li><a href="#">Enquire</a></li>     -->
                                <li><a href="#">Careers</a></li>    
                                <li><a href="#">Contact</a></li>    
                                <!-- <li><a href="#">Service</a></li>     -->
                            </ul>                     
                        </div>
                    </div>
                </div>
                <!--End single footer widget-->

                <!--Start single footer widget-->
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 wow animated fadeInUp" data-wow-delay="0.5s">
                    <div class="single-footer-widget martop">
                        <div class="title">
                            <h3>Locations</h3>
                            <div class="decor">
                                <img src="assets/images/shape/decor.png" alt="">
                            </div>
                        </div>
                        <div class="single-footer-widget-Location">
                            <div class="owl-carousel owl-theme one-item-carousel owl-nav-style-one location_carousel">
                                <!--Start Single Location Box-->
                                <div class="single-Location-box">
                                    <h4>Kallakurichi</h4>
                                    <p>280 Granite Run Drive <br>Suite #200 Lancaster, PA 1760</p>
                                    <div class="phone">
                                        <a href="tel:+919865696688">+91 98656 96688</a>
                                    </div>
                                    <div class="email">
                                        <a href="mailto:aquaasshinee@gmail.com">aquaasshine@gmail.com</a>
                                    </div>
                                </div>
                                <!--End Single Location Box-->
                                <!--Start Single Location Box-->
                                <div class="single-Location-box">
                                    <h4>Virudhachalam</h4>
                                    <p>280 Granite Run Drive <br>Suite #200 Lancaster, PA 1760</p>
                                    <div class="phone">
                                        <a href="tel:+919865696688">+91 98656 96688</a>
                                    </div>
                                    <div class="email">
                                        <a href="mailto:aquaasshinee@gmail.com">aquaasshine@gmail.com</a>
                                    </div>
                                </div>
                                <!--End Single Location Box-->
                            </div>
                        </div>
                    </div>
                </div>
                <!--End single footer widget-->

                <!--Start single footer widget-->
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 wow animated fadeInUp" data-wow-delay="0.7s">
                    <div class="single-footer-widget martop pdtop50">
                        <div class="title">
                            <h3>Business Hours</h3>
                            <div class="decor">
                                <img src="assets/images/shape/decor.png" alt="">
                            </div>
                        </div>
                        <div class="single-footer-widget-business-hours">
                            <ul>
                                <li>Mon-Friday:<br />08.00 am to 08.00 pm</li>
                                <li>Satday:<br />09.00 am to 03.00 pm</li>
                            </ul>
                            <div class="btn-box">
                                <a class="btn-one" href="#contact-form">
                                    <div class="round"></div>
                                    <span class="txt">Enquiry Now</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                

            </div>
        </div>
    </div>
    <!--End Footer-->


    <div class="footer-bottom">
        <div class="container">
            <div class="bottom-inner clearfix">
                <div class="copyright pull-left">
                    <p>Copyright &copy;<a href="index.php"> 2024 Aquaasshine.</a> All Rights Reserved.</p>
                </div>
                <ul class="footer-nav pull-right clearfix">
                    <li><a href="index.php">Terms & Conditions</a></li>
                    <li><a href="index.php">Privacy Policy</a></li>
                    <li><a href="index.php">Sitemap</a></li>
                </ul>
            </div>
        </div>
    </div>

</footer>  