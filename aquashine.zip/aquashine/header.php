<!-- Main header-->
<header class="main-header header-style-one">
    <div class="header-top">
        <div class="container">
            <div class="outer-box clearfix">
                <div class="header-top_left pull-left">
                    <div class="text">
                        <p>Immediate Delivery</p>
                    </div>
                    <div class="header-contact-info1">
                        <ul>
                            <li><span class="icon-calling"></span><a href="tel:+919865696688">+919865 696688</a></li>
                            <li><span class="icon-clock"></span>Mon - Fri: 08.00 to 08.00</li>
                        </ul>
                    </div>
                </div>
                <div class="header-top_right pull-right">
                    <div class="header-mail-box">
                        <span class="icon-email"></span>
                        <p>Enquire? <a href="mailto:aquaasshinee@gmail.com">Send Your Mail</a></p>
                    </div>
                    <div class="space-box1"></div>
                    <div class="our-service-location-area">
                        <div class="icon">
                            <span class="icon-placeholder"></span>
                        </div>
                        <div class="select-box clearfix">
                            <select class="wide">
                               <option data-display="Service Area">Service Area</option>
                               <option value="1">Kallakurichi</option>
                               <option value="2">Virudhachalam</option>
                            </select>
                        </div>
                    </div>
                </div>

            </div>
        </div>    
    </div>

    <!--Start Header--> 
    <div class="header">
        <div class="auto-container">
            <div class="outer-box">
                <div class="header-left">
                    <div class="logo">
                        <a href="index.php"><img src="assets/images/resources/logo5.png" alt="Awesome Logo" title="" width="200px" height="200px"></a>
                    </div>
                </div>

                <div class="header-right">
                    <div class="nav-outer style1 clearfix">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler">
                            <div class="inner">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </div>
                        </div>
                        <!-- Main Menu -->
                        <nav class="main-menu style1 navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">
                                    <li class="current"><a href="#"><span>Home</span></a>
                                    </li>
                                    <li><a href="#service-area"><span>Services</span></a>
                                    </li>
                                    <li><a href="#product-area"><span>Products</span></a>
                                    </li>
                                    <li><a href="career.html"><span>Career</span></a>
                                    </li>
                                    <li><a href="contact.html"><span>Contact</span></a></li>
                                </ul>
                            </div>
                        </nav>                        
                        <!-- Main Menu End-->
                    </div>
                    
                    <div class="space-box2"></div>
                    <div class="header-social-link-1">
                        <div class="social-link">
                            <ul class="clearfix">
                                <li><a href="https://www.facebook.com/aquaasshine"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="https://www.instagram.com/aquashine_official"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>    
                    </div>  
                    
                    <div class="header-right_buttom">
                        <div class="btns-box">
                            <a class="btn-one" href="tel:+919865 696688">
                                <div class="round"></div>
                                <span class="txt">Call Now</span>
                            </a>
                        </div>
                    </div> 

                </div> 
            </div>
        </div>    
    </div> 
    <!--End header-->

    <!--Sticky Header-->
    <div class="sticky-header">
        <div class="container">
            <div class="clearfix">
                <!--Logo-->
                <div class="logo float-left">
                    <a href="index.php" class="img-responsive"><img src="assets/images/resources/logo5.png" alt="" title="" width="200px"height="200px"></a>
                </div>
                <!--Right Col-->
                <div class="right-col float-right">
                    <!-- Main Menu -->
                    <nav class="main-menu clearfix">
                    <!--Keep This Empty / Menu will come through Javascript-->
                    </nav>   
                </div>
            </div>
        </div>
    </div>
    <!--End Sticky Header-->
    
    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><span class="icon fa fa-times-circle"></span></div>
        <nav class="menu-box">
            <div class="nav-logo"><a href="index.php"><img src="assets/images/resources/logo5.png" alt="" title="" width="200px"height="200px"></a></div>
            <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
            <!--Social Links-->
            <div class="social-links">
                <ul class="clearfix">
                    <li><a href="https://www.facebook.com/aquaasshine"><span class="fab fa fa-facebook-square"></span></a></li>
                    <!-- <li><a href="#"><span class="fab fa fa-twitter-square"></span></a></li> -->
                    <!-- <li><a href="#"><span class="fab fa fa-pinterest-square"></span></a></li>
                    <li><a href="#"><span class="fab fa fa-google-plus-square"></span></a></li> -->
                    <li><a href="https://www.instagram.com/aquashine_official"><span class="fab fa fa-instagram-square"></span></a></li>
                </ul>
            </div>
        </nav>
    </div>
    <!-- End Mobile Menu --> 

</header>