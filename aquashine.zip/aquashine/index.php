<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Aguapure - Responsive HTML 5 Template</title>

	<!-- responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Google Fonts -->

    <link href="https://fonts.googleapis.com/css2?family=Laila:wght@300;400;500;600;700&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam:ital,wght@0,100;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,300;1,400;1,500;1,600;1,700;1,800&amp;display=swap" rel="stylesheet">

	<link rel="stylesheet" href="assets/css/animate.css">  
	<link rel="stylesheet" href="assets/css/aos.css">  
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">	
	<link rel="stylesheet" href="assets/css/bootstrap-select.min.css">
	<link rel="stylesheet" href="assets/css/custom-animate.css">
	<link rel="stylesheet" href="assets/css/fancybox.min.css">
	<link rel="stylesheet" href="assets/css/flaticon.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/imp.css">
	<link rel="stylesheet" href="assets/css/jquery-ui.css">
	<link rel="stylesheet" href="assets/css/magnific-popup.css">
	<link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/rtl.css">
	<link rel="stylesheet" href="assets/css/scrollbar.css">
	<link rel="stylesheet" href="assets/css/icomoon.css">
	<link rel="stylesheet" href="assets/css/jquery.bootstrap-touchspin.css">
	<link rel="stylesheet" href="assets/css/nice-select.css">

    <!-- Module css -->
    <link rel="stylesheet" href="assets/css/module-css/header-section.css">
	<link rel="stylesheet" href="assets/css/module-css/banner-section.css">
	<link rel="stylesheet" href="assets/css/module-css/about-section.css">
	<link rel="stylesheet" href="assets/css/module-css/blog-section.css">
	<link rel="stylesheet" href="assets/css/module-css/fact-counter-section.css">
	<link rel="stylesheet" href="assets/css/module-css/faq-section.css">
	<link rel="stylesheet" href="assets/css/module-css/contact-page.css">
	<link rel="stylesheet" href="assets/css/module-css/breadcrumb-section.css">
	<link rel="stylesheet" href="assets/css/module-css/team-section.css">
	<link rel="stylesheet" href="assets/css/module-css/partner-section.css">
	<link rel="stylesheet" href="assets/css/module-css/testimonial-section.css">
	<link rel="stylesheet" href="assets/css/module-css/services-section.css">
	<link rel="stylesheet" href="assets/css/module-css/footer-section.css">
   
    <link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="assets/css/responsive.css">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16"> 

</head>

<body>

<div class="boxed_wrapper ltr">

<!-- Preloader -->
<div class="loader-wrap">
    <div class="layer layer-one"><span class="overlay"></span></div>
    <div class="layer layer-two"><span class="overlay"></span></div>        
    <div class="layer layer-three"><span class="overlay"></span></div>        
</div>

<!-- page-direction -->
<div class="page_direction">
    <div class="demo-rtl direction_switch"><button class="rtl">RTL</button></div>
    <div class="demo-ltr direction_switch"><button class="ltr">LTR</button></div>
</div>
<!-- page-direction end -->


<!-- Header Section -->
<?php include "header.php" ?>
<!-- End Header Section -->

<!-- Start Main Slider -->
<section class="main-slider style1">
    <div class="slider-box">
        <!-- Banner Carousel -->
        <div class="banner-carousel owl-theme owl-carousel">
            <!-- Slide -->
            <div class="slide">
                <div class="image-layer" style="background-image:url(assets/images/slides/slide-v1-1.jpg)"></div>
                <div class="slider-bg-box" style="background-image: url(assets/images/slides/slide-v1-1-bg1.jpg);"></div>
                <div class="slider-image" style="padding-left: 200px;"><img class="float-bob-y" src="assets/images/slides/banner-purifier.png" alt=""></div>
                <div class="round-box">
                    <h3>Aadi<br> Offer</h3>
                    <h2>10%</h2>
                    <p>only for Exchange</p>
                </div>
                <div class="auto-container">
                    <div class="content">
                        <div class="big-title">
                            <h2 style="font-size: 20px;">Best Water Purifier Service Provider</h2>
                            <br>
                            <h2>Healthy Water, <br> Healthy Family, <br> Happy Life.</h2>
                        </div>
                        <div class="text">
                            <p>Aquaasshine offers the best RO purifier service right at your doorstep, <br>ensuring clean and safe drinking water for your family.</p>
                            <!-- <p>Aquaasshine offer Good health begins with clean water.<br>Keep your family safe and happy with our top-tier RO systems.</p> -->
                        </div>
                        <div class="btns-box">
                            <a class="btn-one" href="#contact-form">
                                <div class="round"></div>
                                <span class="txt">Enquiry Now</span>
                            </a>
                            <!-- <div class="slider-video-gallery">
                                <div class="icon">
                                    <a class="video-popup" title="Video Gallery" href="https://www.youtube.com/watch?v=hv8rs4zAl5Q">
                                        <span class="icon-play playicon"></span>
                                    </a>
                                </div>
                                <div class="title">
                                    <h6>Watch Video</h6>
                                    <p>Production to Delivery</p>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Slide -->
            <div class="slide">
                <div class="image-layer" style="background-image:url(assets/images/slides/slide-v1-1.jpg)"></div>
                <div class="slider-bg-box" style="background-image: url(assets/images/slides/slide-v1-1-bg2.jpg);"></div>
                <div class="slider-image"><img class="float-bob-y" src="assets/images/slides/banner2-purifier.png" alt=""></div>
                <div class="round-box">
                    <h3>Aadi<br>Offer</h3>
                    <h2>10%</h2>
                    <p>Only for Exchange</p>
                </div>
                <div class="auto-container">
                    <div class="content">
                        <div class="big-title">
                            <h2 style="font-size: 20px;">Buy a Best Water purifier for home</h2>
                            <br>
                            <h2>Experience <br> Purity with <br> Every Drop.</h2>
                        </div>
                        <div class="text">
                            <p>Choose Aquaasshine for your new purifier and ensure <br>a healthy life for your family.</p>
                            <!-- <p>Discover the difference of pure water.<br>Our advanced RO technology ensures every drop is perfect.</p> -->
                        </div>
                        <div class="btns-box">
                            <a class="btn-one" href="#contact-form">
                                <div class="round"></div>
                                <span class="txt">Enquiry Now</span>
                            </a>
                            <!-- <div class="slider-video-gallery">
                                <div class="icon">
                                    <a class="video-popup" title="Video Gallery" href="https://www.youtube.com/watch?v=hv8rs4zAl5Q">
                                        <span class="icon-play playicon"></span>
                                    </a>
                                </div>
                                <div class="title">
                                    <h6>Watch Video</h6>
                                    <p>Production to Delivery</p>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Slide -->
            <div class="slide">
                <div class="image-layer" style="background-image:url(assets/images/slides/slide-v1-1.jpg)"></div>
                <div class="slider-bg-box" style="background-image: url(assets/images/slides/slide-v1-1-bg1.jpg);"></div>
                <div class="slider-image"><img class="float-bob-y" src="assets/images/slides/banner-purifier.png" alt=""></div>
                <div class="round-box">
                    <h3>Aadi<br>Offer</h3>
                    <h2>10%</h2>
                    <p>Only for Exchange</p>
                </div>
                <div class="auto-container">
                    <div class="content">
                        <div class="big-title">
                            <h2 style="font-size: 20px;">Water Purifier Sales and Service Near You</h2>
                            <br>
                            <h2>Quality Water <br> For a Better <br> Tomorrow.</h2>
                        </div>
                        <div class="text">
                            <p>Reach out to Aquaasshine for the best RO purifier <br>sales and service, dedicated to your family's health.</p>
                            <!-- <p>Invest in a healthier future.<br>Our RO purifiers provide clean water today for a better tomorrow.</p> -->
                        </div>
                        <div class="btns-box">
                            <a class="btn-one" href="#contact-form">
                                <div class="round"></div>
                                <span class="txt">Enquiry Now</span>
                            </a>
                            <!-- <div class="slider-video-gallery">
                                <div class="icon">
                                    <a class="video-popup" title="Video Gallery" href="https://www.youtube.com/watch?v=hv8rs4zAl5Q">
                                        <span class="icon-play playicon"></span>
                                    </a>
                                </div>
                                <div class="title">
                                    <h6>Watch Video</h6>
                                    <p>Production to Delivery</p>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
           
        </div>
    </div>
</section>
<!-- End Main Slider -->


<!--Start Service Style1 Area-->
<section class="service-style1-area" id=service-area>
    <div class="service-style1_pattern-bg" style="background-image: url(assets/images/pattern/service-style1-area-pt.jpg);"></div>
    <div class="container">
        <div class="sec-title text-center">
            <div class="sub-title">
                <h5>our Services</h5>
            </div>
            <h2>Excellence in Every <br> Service We Offer.</h2>
            <div class="decor">
                <img src="assets/images/shape/decor.png" alt="">
            </div>
        </div>
        <div class="row">
            <!--Start Single Service Style1-->
            <div class="col-xl-4 col-lg-4">
                <div class="single-service-style1 text-center wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                    <div class="single-service-style1__bg" style="background-image: url(assets/images/shape/single-service-box-bg.png);"></div>
                    <div class="img-holder">
                        <div class="inner">
                            <img src="assets/images/services/service-v1-1.jpg" alt="">
                        </div>
                        <div class="overlay-icon">
                            <a href="#"><span class="icon-water-bottle"></span></a>
                        </div>
                    </div>
                    <div class="title-holder">
                        <h3><a href="services-details.html">Bottled Water</a></h3>
                        <div class="inner-text">
                            <p>Nor again there any who loves pursue desires to obtain  itself.</p>
                        </div>
                        <div class="readmore-button">
                            <a href="services-details.html"><span class="icon-right-arrow"></span>Read More</a>
                        </div>
                    </div>
                </div>
            </div> 
            <!--End Single Service Style1-->
            <!--Start Single Service Style1-->
            <div class="col-xl-4 col-lg-4">
                <div class="single-service-style1 text-center wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                    <div class="single-service-style1__bg" style="background-image: url(assets/images/shape/single-service-box-bg.png);"></div>
                    <div class="img-holder">
                        <div class="inner">
                            <img src="assets/images/services/service-v1-2.jpg" alt="">
                        </div>
                        <div class="overlay-icon">
                            <a href="#"><span class="icon-water-dispenser"></span></a>
                        </div>
                    </div>
                    <div class="title-holder">
                        <h3><a href="services-details.html">Water Dispenser</a></h3>
                        <div class="inner-text">
                            <p> Too take a trivial example which every obtain some advantage.</p>
                        </div>
                        <div class="readmore-button">
                            <a href="services-details.html"><span class="icon-right-arrow"></span>Read More</a>
                        </div>
                    </div>
                </div>
            </div> 
            <!--End Single Service Style1--> 
            <!--Start Single Service Style1-->
            <div class="col-xl-4 col-lg-4">
                <div class="single-service-style1 text-center wow fadeInUp" data-wow-delay="400ms" data-wow-duration="1500ms">
                    <div class="single-service-style1__bg" style="background-image: url(assets/images/shape/single-service-box-bg.png);"></div>
                    <div class="img-holder">
                        <div class="inner">
                            <img src="assets/images/services/service-v1-3.jpg" alt="">
                        </div>
                        <div class="overlay-icon">
                            <a href="#"><span class="icon-tank"></span></a>
                        </div>
                    </div>
                    <div class="title-holder">
                        <h3><a href="services-details.html">Water Trailers</a></h3>
                        <div class="inner-text">
                            <p>Find faults with man chooses enjoy at consequences avoids.</p>
                        </div>
                        <div class="readmore-button">
                            <a href="services-details.html"><span class="icon-right-arrow"></span>Read More</a>
                        </div>
                    </div>
                </div>
            </div> 
            <!--End Single Service Style1-->  
        </div>

        <div class="row">
            <div class="col-xl-12">
                <div class="service-style1_btns-box text-center">
                    <a class="btn-one" href="services.html">
                        <div class="round"></div>
                        <span class="txt">View All</span>
                    </a>
                </div>
            </div>
        </div>

    </div>
</section>
<!--End Service Style1 Area-->

<!--Start Fact Counter Area-->
<section class="fact-counter-area">
    <div class="auto-container">
        <div class="row">
            <div class="col-xl-12">
                <div class="fact-counter_box">
                    <ul class="clearfix">
                        <li class="single-fact-counter wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <!-- <div class="border-box"><img src="assets/images/shape/fact-counter-border.png" alt=""/></div> -->
                            <div class="outer-box">
                                <div class="count-outer count-box">
                                    <span class="count-text" data-speed="3000" data-stop="5">0</span>
                                    <span class="k">k+</span>
                                </div>
                                <div class="title">
                                    <h6>Purifier Machines<br> Delivered</h6>
                                </div>
                            </div>  
                        </li>
                        <li class="single-fact-counter wow slideInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                            <!-- <div class="border-box"><img src="assets/images/shape/fact-counter-border.png" alt=""/></div> -->
                            <div class="outer-box">
                                <div class="count-outer count-box">
                                    <span class="count-text" data-speed="3000" data-stop="10">0</span>
                                    <span class="plus">+</span>
                                </div>
                                <div class="title">
                                    <h6>Years of <br>Experienced</h6>
                                </div>
                            </div>  
                        </li>
                        <li class="single-fact-counter wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <!-- <div class="border-box"><img src="assets/images/shape/fact-counter-border.png" alt=""/></div> -->
                            <div class="outer-box">
                                <div class="count-outer count-box">
                                    <span class="count-text" data-speed="3000" data-stop="8">0</span>
                                    <span class="plus">k+</span>
                                </div>
                                <div class="title">
                                    <h6>Services <br>Provides</h6>
                                </div>
                            </div>  
                        </li>
                        <li class="single-fact-counter wow slideInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                            <!-- <div class="border-box"><img src="assets/images/shape/fact-counter-border.png" alt=""/></div> -->
                            <div class="outer-box">
                                <div class="count-outer count-box">
                                    <span class="count-text" data-speed="3000" data-stop="4.8">0.1</span>
                                    <span class="plus">★</span>
                                </div>
                                <div class="title">
                                    <h6>Client<br/>Rating</h6>
                                </div>
                            </div>  
                        </li>
                        <li class="single-fact-counter wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="border-box"></div>
                            <div class="outer-box">
                                <div class="count-outer count-box">
                                    <span class="count-text" data-speed="3000" data-stop="25000">0</span>
                                </div>
                                <div class="title">
                                    <h6>Happy <br>Customers</h6>
                                </div>
                            </div>  
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>   
<!--End Fact Counter Area-->

<!--Start About Style1 Area-->
<section class="about-style1-area">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="about-style1_top">
                    <div class="sec-title">
                        <div class="sub-title">
                            <h5>About AquaaSshine</h5>
                        </div>
                        <h2 style="font-size: 40px;">Discover Aquaasshine: <br>Your Trusted Partner in Ro Water Purifer</h2>
                        <!-- <h2>Spring water <br>to homes & businesses</h2> -->
                        <div class="decor">
                            <img src="assets/images/shape/decor.png" alt="">
                        </div>
                    </div>
                    <!-- <div class="our-certification-box">
                        <div class="certificate-logo">
                            <img src="assets/images/resources/certification-logo.png" alt="">
                        </div>
                        <div class="text">
                            <h3><span>nsf & ibwa</span><br> Certified Company</h3>
                            <p>How all this mistaken denouncing pleasure & praising.</p>
                        </div>
                    </div>     -->
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-12">
                <div class="about-style1_content">
                    <div class="about-style1_tab tabs-box">
                        <ul class="tab-buttons clearfix">
                            <li data-tab="#about" class="tab-btn active-btn">
                                <div class="left">
                                    <h2>01.</h2>
                                </div>
                                <div class="right">
                                    <h5>Story of<br> Aquaasshine</h5>
                                </div>
                            </li>
                            <li data-tab="#goal" class="tab-btn">
                                <div class="left">
                                    <h2>02.</h2>
                                </div>
                                <div class="right">
                                    <h5>Company<br> Goal & Values</h5>
                                </div>
                            </li>
                        </ul>

                        <div class="tabs-content">
                            <div class="pattern-bg" style="background-image: url(assets/images/pattern/thm-pattern-1.png);"></div>
                            <!--Tab-->
                            <div class="tab active-tab" id="about">
                                <div class="about-style1-tab-content clearfix">
                                    <div class="about-style1-tab-content_bg" style="background-image: url(assets/images/about/about-style1.jpg);"></div>
                                    <div class="inner-content">
                                        <div class="sec-title">
                                            <h2>Decade of Dedication by Our Family</h2>
                                            <div class="decor">
                                                <img src="assets/images/shape/decor.png" alt="">
                                            </div>
                                        </div>
                                        <p>Aquaasshine is a family-run business with over a decade of commitment to providing exceptional RO purifier solutions. Our dedication to clean water and customer satisfaction is the cornerstone of our success.</p>
                                        <div class="btn-box">
                                            <!-- <a class="btn-two" href="about.html"><span class="icon-right-arrow"></span>Read More</a> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--Tab-->
                            <!--Tab-->
                            <div class="tab" id="goal">
                                <div class="about-style1-tab-content clearfix">
                                    <div class="about-style1-tab-content_bg" style="background-image: url(assets/images/about/about-style1-2.png);"></div>
                                    <div class="inner-content">
                                        <div class="sec-title">
                                            <h2>Our Goals and Values: Committed to Purity and Service Excellence</h2>
                                            <div class="decor">
                                                <img src="assets/images/shape/decor.png" alt="">
                                            </div>
                                        </div>
                                        <p>At Aquaasshine, our goal is to deliver top-quality RO purifiers and exceptional service. We value integrity, reliability, and innovation, ensuring clean, safe water for every home. Our commitment is to provide the highest standards in water purification and customer satisfaction.</p>
                                        <div class="btn-box">
                                            <!-- <a class="btn-two" href="about.html"><span class="icon-right-arrow"></span>Read More</a> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--Tab-->
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<!--End About Style1 Area-->

<!--Start Shop Style1 Area-->
<section class="shop-style1-area" id="product-area">
    <div class="shop-top-image-box">
        <div class="inner">
            <img src="assets/images/resources/shop-top-image.jpg" alt="">
        </div>
        <div class="ice paroller">
            <img class="zoom-fade" src="assets/images/resources/ice.png" alt="">
        </div>
        <div class="round-box paroller-2">
            <h3>No<br> Minimum<br> Order</h3>    
        </div>
    </div>
    <div class="big-title">100% Pure Water.Natural</div>
    <div class="auto-container">
        <div class="sec-title text-center">
            <div class="sub-title">
                <h5>Our Products</h5>
            </div>
            <h2>Delivered fresh to your door <br>by our team.</h2>
            <div class="decor">
                <img src="assets/images/shape/decor.png" alt="">
            </div>
        </div>
        <div class="shop-style1_content">
            <!--Start Single Shop Item-->
            <div class="single-shop-item">
                <div class="single-shop-item_inner">
                    <div class="img-holder">
                        <img src="assets/images/shop/shop-1.jpg" alt="">
                        <div class="overlay">
                            <span class="icon-email"></span>
                            <a href="#">Enquire</a>
                        </div>
                    </div>
                    <div class="product-quantity-box">
                        <div class="input-box">
                            <span>Quantity:</span>
                            <input class="quantity-spinner" type="text" value="1" name="quantity">
                        </div>
                        <div class="rate-box">
                            <h3>$12.50</h3>
                        </div>  
                    </div>
                    <div class="title-holder">
                        <h3><a href="product-details.html">2 Ltr Bottled Water</a></h3>
                        <h6>Delivery</h6>
                        <p>Tom 4:30pm - 6:30pm</p>
                        <div class="btn-box">
                            <a class="btn-one" href="product-details.html">
                                <div class="round"></div>
                                <span class="txt">Add to Cart</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Single Shop Item-->
            <!--Start Single Shop Item-->
            <div class="single-shop-item">
                <div class="single-shop-item_inner">
                    <div class="img-holder">
                        <img src="assets/images/shop/shop-2.jpg" alt="">
                        <div class="overlay">
                            <span class="icon-email"></span>
                            <a href="#">Enquire</a>
                        </div>
                    </div>
                    <div class="product-quantity-box">
                        <div class="input-box">
                            <span>Quantity:</span>
                            <input class="quantity-spinner" type="text" value="1" name="quantity">
                        </div>
                        <div class="rate-box">
                            <h3>$20.00</h3>
                        </div>  
                    </div>
                    <div class="title-holder">
                        <h3><a href="product-details.html">15 Ltr Bottled Water</a></h3>
                        <h6>Delivery</h6>
                        <p>Mon 9:30am - 10:30am</p>
                        <div class="btn-box">
                            <a class="btn-one" href="product-details.html">
                                <div class="round"></div>
                                <span class="txt">Add to Cart</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Single Shop Item-->
            <!--Start Single Shop Item-->
            <div class="single-shop-item">
                <div class="single-shop-item_inner">
                    <div class="img-holder">
                        <img src="assets/images/shop/shop-3.jpg" alt="">
                        <div class="overlay">
                            <span class="icon-email"></span>
                            <a href="#">Enquire</a>
                        </div>
                    </div>
                    <div class="product-quantity-box">
                        <div class="input-box">
                            <span>Quantity:</span>
                            <input class="quantity-spinner" type="text" value="1" name="quantity">
                        </div>
                        <div class="rate-box">
                            <h3>$16.00</h3>
                        </div>  
                    </div>
                    <div class="title-holder">
                        <h3><a href="product-details.html">12 Ltr Bottled Water</a></h3>
                        <h6>Delivery</h6>
                        <p>Tom 4:30pm - 6:30pm</p>
                        <div class="btn-box">
                            <a class="btn-one" href="product-details.html">
                                <div class="round"></div>
                                <span class="txt">Add to Cart</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Single Shop Item-->
            <!--Start Single Shop Item-->
            <div class="single-shop-item">
                <div class="single-shop-item_inner">
                    <div class="img-holder">
                        <img src="assets/images/shop/shop-4.jpg" alt="">
                        <div class="overlay">
                            <span class="icon-email"></span>
                            <a href="#">Enquire</a>
                        </div>
                    </div>
                    <div class="product-quantity-box">
                        <div class="input-box">
                            <span>Quantity:</span>
                            <input class="quantity-spinner" type="text" value="1" name="quantity">
                        </div>
                        <div class="rate-box">
                            <h3>$25.50</h3>
                        </div>  
                    </div>
                    <div class="title-holder">
                        <h3><a href="product-details.html">15+2 Ltr Combo Pack</a></h3>
                        <h6>Delivery</h6>
                        <p>Tom 4:30pm - 6:30pm</p>
                        <div class="btn-box">
                            <a class="btn-one" href="product-details.html">
                                <div class="round"></div>
                                <span class="txt">Add to Cart</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Single Shop Item-->
            <!--Start Single Shop Item-->
            <div class="single-shop-item">
                <div class="single-shop-item_inner">
                    <div class="img-holder">
                        <img src="assets/images/shop/shop-5.jpg" alt="">
                        <div class="overlay">
                            <span class="icon-email"></span>
                            <a href="#">Enquire</a>
                        </div>
                    </div>
                    <div class="product-quantity-box">
                        <div class="input-box">
                            <span>Quantity:</span>
                            <input class="quantity-spinner" type="text" value="1" name="quantity">
                        </div>
                        <div class="rate-box">
                            <h3>$69.00</h3>
                        </div>  
                    </div>
                    <div class="title-holder">
                        <h3><a href="product-details.html">Water Dispenser</a></h3>
                        <h6>Delivery</h6>
                        <p>Mon 8:30am - 9:30am</p>
                        <div class="btn-box">
                            <a class="btn-one" href="product-details.html">
                                <div class="round"></div>
                                <span class="txt">Add to Cart</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Single Shop Item-->
        </div>
    </div>
</section>
<!--End Shop Style1 Area-->

<!--Start Choose Style1 Area-->
<section class="choose-style1-area">
    <div class="container">
        <div class="row">
            <div class="col-xl-4">
                <div class="choose-style1_image-box wow slideInLeft" data-wow-delay="100ms" data-wow-duration="2500ms">
                    <img src="assets/images/resources/choose-style1-img.jpg" alt=""/>
                    <!-- <div class="round-box js-tilt paroller">
                        <h3 style="padding-top: -200px;">No<br> Minimum<br> Order</h3>    
                    </div> -->
                </div>
            </div>
            <div class="col-xl-8">
                <div class="choose-style1-content">
                    <div class="sec-title">
                        <div class="sub-title">
                            <h5>Why Aguapure</h5>
                        </div>
                        <h2>You’ll love fresh <br>taste of our natural water</h2>
                        <div class="decor">
                            <img src="assets/images/shape/decor.png" alt="">
                        </div>
                    </div>
                    <div class="inner-content">
                        <div class="shape">
                            <img src="assets/images/shape/choose-style1-shape-1.png" alt="">
                        </div>
                        <ul class="clearfix">
                            <li class="wow fadeInLeft" data-wow-delay="100ms" data-wow-duration="1500ms">
                                <div class="icon">
                                    <div class="icon-bg" style="background-image: url(assets/images/shape/thm-shape-1.png);"></div>
                                    <span class="icon-water-drop-1"></span>
                                </div>
                                <div class="text">
                                    <h3>High Quality</h3>
                                    <p>Take a trivial example which ever undertake laboris physical some advantage.</p>
                                </div>
                            </li>
                            <li class="wow fadeInRight" data-wow-delay="100ms" data-wow-duration="1500ms">
                                <div class="icon">
                                    <div class="icon-bg" style="background-image: url(assets/images/shape/thm-shape-1.png);"></div>
                                    <span class="icon-write-message"></span>
                                </div>
                                <div class="text">
                                    <h3>No Contract</h3>
                                    <p>Righteous indignation & dislike men who are beguiled the charms blinded desire.</p>
                                </div>
                            </li>
                        </ul> 
                        <ul class="clearfix">
                            <li class="wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
                                <div class="icon">
                                    <div class="icon-bg" style="background-image: url(assets/images/shape/thm-shape-1.png);"></div>
                                    <span class="icon-shield"></span>
                                </div>
                                <div class="text">
                                    <h3>Reliable</h3>
                                    <p>Equal blame belongs those who fail in their duty through weaknes of shrinking.</p>
                                </div>
                            </li>
                            <li class="wow fadeInRight" data-wow-delay="300ms" data-wow-duration="1500ms">
                                <div class="icon">
                                    <div class="icon-bg" style="background-image: url(assets/images/shape/thm-shape-1.png);"></div>
                                    <span class="icon-medal"></span>
                                </div>
                                <div class="text">
                                    <h3>Certified</h3>
                                    <p>Take a trivial example which ever undertake laboris physical some advantage.</p>
                                </div>
                            </li>
                        </ul>
                        <ul class="clearfix">
                            <li class="wow fadeInLeft" data-wow-delay="500ms" data-wow-duration="1500ms">
                                <div class="icon">
                                    <div class="icon-bg" style="background-image: url(assets/images/shape/thm-shape-1.png);"></div>
                                    <span class="icon-hand"></span>
                                </div>
                                <div class="text">
                                    <h3>Affordable</h3>
                                    <p>Righteous indignation & dislike men who are beguiled the charms blinded desire.</p>
                                </div>
                            </li>
                            <li class="wow fadeInRight" data-wow-delay="600ms" data-wow-duration="1500ms">
                                <div class="icon">
                                    <div class="icon-bg" style="background-image: url(assets/images/shape/thm-shape-1.png);"></div>
                                    <span class="icon-truck"></span>
                                </div>
                                <div class="text">
                                    <h3>Fast Delivery</h3>
                                    <p>Equal blame belongs those who fail in their duty through weaknes of shrinking.</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!--End Choose Style1 Area-->

<!--Start Features Style1 Area-->
<section class="features-style1-area">
    <div class="auto-container">
        <div class="row">
            <div class="col-xl-6">
                <div class="features-style1_one-content">
                    <div class="features-style1_one-content-bg" style="background-image: url(assets/images/resources/features-style1_one-content-bg.jpg);"></div>
                    <div class="inner-content">
                        <div class="sec-title">
                            <div class="sub-title">
                                <h5>Water & You</h5>
                            </div>
                            <h2>Essential <br>for Healthy Life</h2>
                            <div class="decor">
                                <img src="assets/images/shape/decor.png" alt="">
                            </div>
                        </div>
                        <div class="text">
                            <p>Righteous indignation & dislike men who are beguiled the charms.</p>
                            <ul>
                                <li><span class="icon-water-drop"></span>Carrying nutrients & oxygen</li>
                                <li><span class="icon-water-drop"></span>Aiding digestion</li>
                                <li><span class="icon-water-drop"></span>Normalizing blood pressure</li>
                                <li><span class="icon-water-drop"></span>Stabilizing the heartbeat</li>
                            </ul>
                            <div class="btns-box">
                                <a class="btn-one" href="#">
                                    <div class="round"></div>
                                    <span class="txt">View All</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>    
            </div>

            <div class="col-xl-3">
                <div class="features-style1_single-box">
                    <div class="features-style1_single-box-bg" style="background-image: url(assets/images/resources/features-style1_single-box-bg-1.jpg);"></div>
                    <div class="inner-content">
                        <h2>Healthy Water for<br> Your Staff</h2>
                        <p>Water makes up over 70% of our bodies and is essential for our good health.</p>
                        <div class="btn-box">
                            <a href="#"><i class="fa fa-plus" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3">
                <div class="features-style1_single-box style2">
                    <div class="features-style1_single-box-bg" style="background-image: url(assets/images/resources/features-style1_single-box-bg-2.jpg);"></div>
                    <div class="inner-content">
                        <h2>Offers<br> Rent, Buy or Hire</h2>
                        <p>All prices are Tax inclusive & a minimum order of 2 water bottles per month.</p>
                        <div class="btn-box">
                            <a href="#"><i class="fa fa-plus" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>    
    </div>
</section>
<!--End Features Style1 Area-->


<!--Start Working process area -->
<section class="working-process-area">
    <div class="working-process-area-bg" style="background-image: url(assets/images/parallax-background/working-process-area-bg.jpg);"></div>
    <div class="container">
        <div class="sec-title text-center">
            <div class="sub-title">
                <h5>How we Work?</h5>
            </div>
            <h2 class="clr_white">A higher standard of water<br> delivered process</h2>
            <div class="decor">
                <img src="assets/images/shape/decor.png" alt="">
            </div>
        </div>
        <div class="row">
            <!--Start Working process Single-->
            <div class="col-xl-4">
                <div class="single-working-process wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                    <div class="counting-box clearfix">
                        <div class="text">
                            <h6>Step</h6>
                        </div>
                        <div class="count"></div>
                    </div>
                    <div class="content">
                        <h3>Order Your Bottle</h3>
                        <p>Foresee the pain and trouble that are bound to ensue and equal blame fail.</p>
                    </div>
                    <div class="icon">
                        <span class="icon-order"></span>
                    </div>
                </div>
            </div>
            <!--End Working process Single-->
            <!--Start Working process Single-->
            <div class="col-xl-4">
                <div class="single-working-process wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                    <div class="counting-box clearfix">
                        <div class="text">
                            <h6>Step</h6>
                        </div>
                        <div class="count"></div>
                    </div>
                    <div class="content">
                        <h3>Touchless Packing</h3>
                        <p>Our power of choice is untrammelled and when nothing prevents our being able.</p>
                    </div>
                    <div class="icon">
                        <span class="icon-package"></span>
                    </div>
                </div>
            </div>
            <!--End Working process Single-->
            <!--Start Working process Single-->
            <div class="col-xl-4">
                <div class="single-working-process wow fadeInUp" data-wow-delay="500ms" data-wow-duration="1500ms">
                    <div class="counting-box clearfix">
                        <div class="text">
                            <h6>Step</h6>
                        </div>
                        <div class="count"></div>
                    </div>
                    <div class="content">
                        <h3>On Time Deliver</h3>
                        <p>Business will frequently occur that who pleasures have to be repudiated & accepted.</p>
                    </div>
                    <div class="icon">
                        <span class="icon-truck-1"></span>
                    </div>
                </div>
            </div>
            <!--End Working process Single-->

        </div>
    </div>
</section>  
<!--End Working process area --> 

<!--Start Contact Style1 Area-->
<section class="contact-style1-area">
    <div class="contact-form-box1_bg" style="background-image: url(assets/images/resources/contact-form-box1_bg.jpg);"></div>
    <div class="thm-round-box1">
        <h3>Top<br> Customer<br> Support</h3>
    </div>
    <div class="gray-bg"></div>
    <div class="container">
        <div class="row">

            <div class="col-xl-6">
                <div class="contact-style1-content">
                    <div class="shape1" data-aos="fade-right" data-aos-easing="linear" data-aos-duration="2000">
                        <img class="paroller-2" src="assets/images/shape/thm-shape-2.png" alt="">
                    </div>
                    <div class="sec-title">
                        <div class="sub-title">
                            <h5>Get In Touch</h5>
                        </div>
                        <h2>Love to assist <br>with your enquiry!</h2>
                        <div class="decor">
                            <img src="assets/images/shape/decor.png" alt="">
                        </div>
                    </div>
                    <div class="inner-content">
                        <div class="quick-contact-box">
                            <div class="icon">
                                <span class="icon-calling"></span>
                            </div>
                            <div class="title">
                                <h3>Quick Contact</h3>
                                <h2><a href="tel:+919865696688">+91 98656 96688</a></h2>
                            </div>
                        </div>
                        <div class="text">
                            <p>Please feel free to call us with any questions or to set<br> up your account.</p>
                        </div>
                        <div class="btn-box">
                            <a class="btn-one" href="tel:+919865696688">
                                <div class="round"></div>
                                <span class="txt">Call Now</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <?php include "form.php" ?>

            <!-- <div class="col-xl-6">
                <div class="contact-form-box1">
                    <div class="top-title">
                        <h2>Enquire With Our Team</h2>
                    </div>
                    <form id="contact-form" name="contact_form" class="default-form1" action="#" method="post">
                        <div class="input-box"> 
                            <input type="text" name="form_name" value="" placeholder="Your Name" required="">
                            <div class="icon">
                                <i class="fa fa-user" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="input-box"> 
                            <input type="email" name="form_email" value="" placeholder="Email Address" required="">
                            <div class="icon">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                        </div> 
                        <div class="input-box">
                            <div class="select-box">
                                <div class="round-shape"></div>
                                <select class="wide">
                                   <option data-display="Service You Need">Service You Need</option>
                                   <option value="1">Bottled Water</option>
                                   <option value="2">Water Dispenser</option>
                                   <option value="3">Water Trailers</option>
                                </select>
                            </div>
                            <div class="icon">
                                <i class="fa fa-cog" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="input-box">
                            <input type="text" name="form_address" value="" placeholder="Your Address">
                            <div class="icon">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                            </div>
                        </div>  
                        <div class="button-box">
                            <div class="left">
                                <div class="checked-box1">
                                    <input type="checkbox" name="skipper1" id="skipper" checked>
                                    <label for="skipper"><span></span>I agree to receive updates<br> from Aguapure</label>
                                </div>
                            </div>
                            <div class="right">
                                <button class="btn-one" type="submit" data-loading-text="Please wait...">
                                    <span class="round"></span>
                                    <span class="txt">Continue</span>
                                </button> 
                            </div>
                        </div>  
                    </form>

                </div>
            </div> -->

        </div>
    </div>
</section>
<!--End Contact Style1 Area-->


<!--Start Testimonials Style1 area -->
<section class="testimonials-style1-area">
    <div class="container">

        <div class="sec-title text-center">
            <div class="sub-title">
                <h5>Testimonials</h5>
            </div>
            <h2>Here's what our customers<br> say about us</h2>
            <div class="decor">
                <img src="assets/images/shape/decor.png" alt="">
            </div>
        </div>
        <div class="row">
            <div class="col-xl-12">
                <div class="theme_carousel testimonials-carousel_1 owl-dot-style1 owl-theme owl-carousel" data-options='{"loop": true, "margin": 30, "autoheight":true, "lazyload":true, "nav": false, "dots": true, "autoplay": true, "autoplayTimeout": 6000, "smartSpeed": 300, "responsive":{ "0" :{ "items": "1" }, "600" :{ "items" : "1" }, "768" :{ "items" : "1" } , "992":{ "items" : "1" }, "1200":{ "items" : "1" }}}'>
                    <!--Start Single Testimonials Style1-->
                    <div class="single-testimonials-style1">
                        <div class="img-box">
                            <img src="assets/images/testimonial/testimonial-v1-1.jpg" alt=""/>
                            <div class="round-1"></div>
                            <div class="round-2"></div>
                        </div>
                        <div class="inner-content">
                            <div class="content-box">
                                <div class="rateing-box">
                                    <ul>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                </div>
                                <h3>I've had the Best Experience</h3>
                                <p>We are extremely happy with  Aguapure's service. They are very prompt. Billing always correct. And they give plenty of notice of the next delivery it is very easy.</p>
                                <h4>Rodha Thelma,  <span>California</span></h4>
                            </div>
                        </div>
                    </div>
                    <!--End Single Testimonials Style1-->
                    <!--Start Single Testimonials Style1-->
                    <div class="single-testimonials-style1">
                        <div class="img-box">
                            <img src="assets/images/testimonial/testimonial-v1-2.jpg" alt=""/>
                            <div class="round-1"></div>
                            <div class="round-2"></div>
                        </div>
                        <div class="inner-content">
                            <div class="content-box">
                                <div class="rateing-box">
                                    <ul>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                </div>
                                <h3>Great Tasting Water & Awesome</h3>
                                <p>Have used their service for five years & can say the service has always been amazing. The delivery driver is friendly. The water tastes really good & we recommend.</p>
                                <h4>Lillian Grace, <span>California</span></h4>
                            </div>
                        </div>
                    </div>
                    <!--End Single Testimonials Style1-->
                    <!--Start Single Testimonials Style1-->
                    <div class="single-testimonials-style1">
                        <div class="img-box">
                            <img src="assets/images/testimonial/testimonial-v1-3.jpg" alt=""/>
                            <div class="round-1"></div>
                            <div class="round-2"></div>
                        </div>
                        <div class="inner-content">
                            <div class="content-box">
                                <div class="rateing-box">
                                    <ul>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                </div>
                                <h3>Team was Very Professional</h3>
                                <p>I went to the Aguapure water office to speak with someone in person about Aguapure services. The  team was very professional and answered all my questions. </p>
                                <h4>Luke Nobert, <span>Los Angeles</span></h4>
                            </div>
                        </div>
                    </div>
                    <!--End Single Testimonials Style1-->
                    <!--Start Single Testimonials Style1-->
                    <div class="single-testimonials-style1">
                        <div class="img-box">
                            <img src="assets/images/testimonial/testimonial-v1-4.jpg" alt=""/>
                            <div class="round-1"></div>
                            <div class="round-2"></div>
                        </div>
                        <div class="inner-content">
                            <div class="content-box">
                                <div class="rateing-box">
                                    <ul>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                </div>
                                <h3>The Water is Delicious</h3>
                                <p>I went to the Aguapure water office to speak with someone in person about Aguapure services. The  team was very professional and answered all my questions. </p>
                                <h4>Luke Nobert, <span>Los Angeles</span></h4>
                            </div>
                        </div>
                    </div>
                    <!--End Single Testimonials Style1-->


                </div>
            </div>
        </div>
    </div>
</section>
<!--End Testimonials Style1 area -->
<section class="faq-style1-area">
    <div class="container">
        <div class="row">

            <div class="col-xl-12 text-right-rtl">
                <div class="faq-style1-content">
                    <div class="faq-style1_tab tabs-box">
                        <ul class="tab-buttons clearfix">
                            <li data-tab="#general-questions" class="tab-btn active-btn">General Questions</li>
                            <li data-tab="#company-service" class="tab-btn">Company & Service</li>
                        </ul>

                        <div class="tabs-content">
                            <div class="pattern-bg" style="background-image: url(assets/images/pattern/thm-pattern-2.png);"></div>
                            <!--Start Tab-->
                            <div class="tab active-tab" id="general-questions"> 
                                <ul class="accordion-box">
                                    <li class="accordion block active-block">
                                        <div class="acc-btn active">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>How much water should I drink?</h3>
                                        </div>
                                        <div class="acc-content current">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>What is Aguapure Water's 100% satisfaction guarantee?</h3>
                                        </div>
                                        <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>What is regeneration?</h3>
                                        </div>
                                        <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>What is in bottled water?</h3>
                                        </div>
                                        <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>What should I consider before buying?</h3>
                                        </div>
                                        <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>Do I need filtering or softening?</h3>
                                        </div>
                                        <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                           <div class="icon-outer"><i class="icon-close"></i></div>
                                           <h3>What does a typical RO system remove from water?</h3>
                                       </div>
                                       <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                       </div>
                                   </li>
                                </ul>
                            </div>
                            <!--End Tab-->
                            <!--Start Tab-->
                            <div class="tab" id="company-service">
                                <ul class="accordion-box">
                                    <li class="accordion block active-block">
                                        <div class="acc-btn active">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>What is Aguapure Water's 100% satisfaction guarantee?</h3>
                                        </div>
                                        <div class="acc-content current">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>What should I consider before buying?</h3>
                                        </div>
                                        <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>Do I need filtering or softening?</h3>
                                        </div>
                                        <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>How much water should I drink?</h3>
                                        </div>
                                        <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>What is regeneration?</h3>
                                        </div>
                                        <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                            <div class="icon-outer"><i class="icon-close"></i></div>
                                            <h3>What is in bottled water?</h3>
                                        </div>
                                        <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                        </div>
                                    </li>
                                    <li class="accordion block">
                                        <div class="acc-btn">
                                           <div class="icon-outer"><i class="icon-close"></i></div>
                                           <h3>What does a typical RO system remove from water?</h3>
                                       </div>
                                       <div class="acc-content">
                                            <p>The wise man therefore always holds in these matters to this principle of selections he rejects pleasures too secure other greater pleasures  trouble that are bound to ensue and equal blame.</p>
                                       </div>
                                   </li>
                                </ul>
                            </div>
                            <!--End Tab-->
                        </div>

                    </div>

                </div>
            </div>
            
        </div>
    </div>   
</section> 

<!--footer area-->
<?php include "footer.php" ?>
<!--End footer area-->


<button class="scroll-top scroll-to-target" data-target="html">
    <span class="icon-right-arrow-1"></span>
</button> 



<!-- search-popup -->
<!-- <div id="search-popup" class="search-popup">
    <div class="close-search"><i class="icon-close"></i></div>
    <div class="popup-inner">
        <div class="overlay-layer"></div>
        <div class="search-form">
            <form method="post" action="">
                <div class="form-group">
                    <fieldset>
                        <input type="search" class="form-control" name="search-input" value="" placeholder="Search Here" required >
                        <input type="submit" value="Search Now!" class="theme-btn style-four">
                    </fieldset>
                </div>
            </form>
            <h3>Recent Search Keywords</h3>
            <ul class="recent-searches">
                <li><a href="index.php">Water Quality</a></li>
                <li><a href="index.php">Mineral</a></li>
                <li><a href="index.php">Bottle</a></li>
                <li><a href="index.php">Safety</a></li>
                <li><a href="index.php">Plan</a></li>
            </ul>
        </div>
    </div>
</div> -->
<!-- search-popup end -->


</div> 


<script src="assets/js/jquery.js"></script>
<script src="assets/js/aos.js"></script>
<script src="assets/js/appear.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/bootstrap-select.min.js"></script>
<script src="assets/js/isotope.js"></script>
<script src="assets/js/jquery.countTo.js"></script>
<script src="assets/js/jquery.easing.min.js"></script>
<script src="assets/js/jquery.enllax.min.js"></script>
<script src="assets/js/jquery.fancybox.js"></script>
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script src="assets/js/jquery.paroller.min.js"></script>
<script src="assets/js/jquery-ui.js"></script>
<script src="assets/js/knob.js"></script>
<script src="assets/js/map-script.js"></script>
<script src="assets/js/owl.js"></script>
<script src="assets/js/pagenav.js"></script>
<script src="assets/js/parallax.min.js"></script>
<script src="assets/js/scrollbar.js"></script>
<script src="assets/js/TweenMax.min.js"></script>
<script src="assets/js/validation.js"></script>
<script src="assets/js/wow.js"></script>

<script src="assets/js/jquery.bootstrap-touchspin.js"></script>
<script src="assets/js/jquery.nice-select.min.js"></script>
<script src="assets/js/tilt.jquery.js"></script>


<script async defer
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyATY4Rxc8jNvDpsK8ZetC7JyN4PFVYGCGM&amp;callback=initMap">
</script>
<!-- thm custom script -->
<script src="assets/js/custom.js"></script>



</body>
</html>